#pragma once

// ============================================================================
// VoiceLock Enterprise — Local Device Configuration (Untracked)
// ============================================================================

#define WIFI_SSID "Team_Rocket"
#define WIFI_PASSWORD "m#P52s@ap$V5g"

#define VOICELOCK_BACKEND_HOST "voicelock-api.orangesand-9922d50e.eastasia.azurecontainerapps.io"
#define VOICELOCK_BACKEND_PORT 443

#define DEVICE_ID "terminal-gate-01"
#define DEVICE_SECRET "YOUR_DEVICE_SECRET"
#define DEFAULT_CLAIMED_IDENTITY "Zubair"
